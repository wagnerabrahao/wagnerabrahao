document.addEventListener('DOMContentLoaded', function() {

    // ===================================================================
    // 1. MENU MOBILE (preservado)
    // ===================================================================
    const menuToggle = document.getElementById('menu-toggle');
    const nav = document.querySelector('nav');

    if (menuToggle) {
        menuToggle.addEventListener('click', function() {
            nav.classList.toggle('active');
            if (nav.classList.contains('active')) {
                menuToggle.classList.remove('fa-bars');
                menuToggle.classList.add('fa-times');
            } else {
                menuToggle.classList.remove('fa-times');
                menuToggle.classList.add('fa-bars');
            }
        });
    }

    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            if (nav.classList.contains('active')) {
                nav.classList.remove('active');
                menuToggle.classList.remove('fa-times');
                menuToggle.classList.add('fa-bars');
            }
        });
    });

    // ===================================================================
    // 2. SISTEMA DE TOAST (notificações suaves)
    // ===================================================================
    function showToast(message, icon = 'fa-check') {
        const existing = document.querySelector('.toast');
        if (existing) existing.remove();

        const toast = document.createElement('div');
        toast.className = 'toast';
        toast.innerHTML = `<i class="fas ${icon}"></i>${message}`;
        document.body.appendChild(toast);

        requestAnimationFrame(() => toast.classList.add('show'));

        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 400);
        }, 2500);
    }

    // ===================================================================
    // 3. MODO ESCURO + TAMANHO DE FONTE
    // ===================================================================
    const themeToggle = document.getElementById('theme-toggle');
    const fontIncrease = document.getElementById('font-increase');
    const fontDecrease = document.getElementById('font-decrease');

    // Carrega preferência salva
    const savedTheme = localStorage.getItem('luz-interior-theme');
    if (savedTheme === 'dark') {
        document.documentElement.setAttribute('data-theme', 'dark');
        if (themeToggle) themeToggle.querySelector('i').className = 'fas fa-sun';
    }

    if (themeToggle) {
        themeToggle.addEventListener('click', function() {
            const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
            if (isDark) {
                document.documentElement.removeAttribute('data-theme');
                themeToggle.querySelector('i').className = 'fas fa-moon';
                localStorage.setItem('luz-interior-theme', 'light');
                showToast('Modo claro ativado', 'fa-sun');
            } else {
                document.documentElement.setAttribute('data-theme', 'dark');
                themeToggle.querySelector('i').className = 'fas fa-sun';
                localStorage.setItem('luz-interior-theme', 'dark');
                showToast('Modo escuro ativado', 'fa-moon');
            }
        });
    }

    // Tamanho de fonte
    let fontScale = parseFloat(localStorage.getItem('luz-interior-font-scale')) || 1;
    document.documentElement.style.setProperty('--font-scale', fontScale);

    function setFontScale(newScale) {
        fontScale = Math.max(0.85, Math.min(1.3, newScale));
        document.documentElement.style.setProperty('--font-scale', fontScale);
        localStorage.setItem('luz-interior-font-scale', fontScale);
    }

    if (fontIncrease) {
        fontIncrease.addEventListener('click', () => {
            setFontScale(fontScale + 0.1);
            showToast('Texto aumentado', 'fa-font');
        });
    }
    if (fontDecrease) {
        fontDecrease.addEventListener('click', () => {
            setFontScale(fontScale - 0.1);
            showToast('Texto reduzido', 'fa-font');
        });
    }

    // ===================================================================
    // 4. AFORISMO DO DIA (com rotação, favoritar, copiar)
    // ===================================================================
    const aphorisms = [
        "O silêncio não é o fim da fala. É o lugar onde a fala finalmente encontra seu sentido.",
        "Soltamos o que amamos não quando paramos de amá-lo, mas quando aprendemos a amá-lo sem precisar possuí-lo.",
        "A sombra não quer destruir você. Quer apenas ser reconhecida pelo nome que você nunca teve coragem de pronunciar.",
        "Entre o estímulo e a resposta há um espaço. Crescer é aprender a habitar esse espaço com dignidade.",
        "A viagem não termina quando se volta para casa. Termina quando se percebe que nunca se saiu de lá.",
        "Não é necessário ir longe para encontrar o silêncio. É necessário parar de ir.",
        "A paz que elimina a tensão não é paz. É anestesia.",
        "Esvaziar não é empobrecer. É criar espaço para que o essencial finalmente caiba.",
        "O equilíbrio não é a estátua de pedra. É a árvore que balança durante o temporal e, por isso mesmo, não cai.",
        "Há uma diferença entre solidão e solitude. A solidão é a ausência de outros. A solitude é a presença de si mesmo.",
        "O mundo não precisa de mais pessoas corretas. Precisa de mais pessoas reais.",
        "A cicatriz não é sinal de derrota. É o mapa de onde a vida passou com mais intensidade.",
        "Nomeie o que dói. O que tem nome pode ser tratado. O que não tem nome governa em silêncio.",
        "A gentileza sem plateia é a mais verdadeira que existe.",
        "Não há chegada. Há apenas o aprofundamento da partida.",
        "A mão fechada não pode receber. Isso vale para presentes, para palavras e para a graça.",
        "Quem aprendeu a habitar o próprio silêncio jamais está completamente só.",
        "Deixar partir não é esquecer. É honrar o que foi sem exigir que ainda seja.",
        "Prestar atenção é o ato mais raro do nosso tempo. É suspender o próprio ruído para que o mundo possa ser ouvido.",
        "A viagem espiral nos devolve ao mesmo ponto mas com uma compreensão que antes não cabia."
    ];

    const aodText = document.getElementById('aod-text');
    const aodFavorite = document.getElementById('aod-favorite');
    const aodShare = document.getElementById('aod-share');
    const aodNew = document.getElementById('aod-new');

    // Determina aforismo do dia com base na data (mesmo dia = mesmo aforismo)
    function getDailyIndex() {
        const today = new Date();
        const start = new Date(today.getFullYear(), 0, 0);
        const diff = today - start;
        const dayOfYear = Math.floor(diff / (1000 * 60 * 60 * 24));
        return dayOfYear % aphorisms.length;
    }

    let currentAphorismIndex = getDailyIndex();

    function renderAphorism(animate = true) {
        if (!aodText) return;
        const text = aphorisms[currentAphorismIndex];
        if (animate) {
            aodText.style.opacity = '0';
            setTimeout(() => {
                aodText.textContent = text;
                aodText.classList.add('aod-animating');
                aodText.style.opacity = '1';
                setTimeout(() => aodText.classList.remove('aod-animating'), 600);
                updateAodFavButton();
            }, 250);
        } else {
            aodText.textContent = text;
            updateAodFavButton();
        }
    }

    function updateAodFavButton() {
        if (!aodFavorite) return;
        const text = aphorisms[currentAphorismIndex];
        const favs = getFavorites();
        const isFav = favs.some(f => f.text === text);
        aodFavorite.classList.toggle('active', isFav);
        aodFavorite.querySelector('i').className = isFav ? 'fas fa-heart' : 'far fa-heart';
    }

    renderAphorism(false);

    if (aodNew) {
        aodNew.addEventListener('click', () => {
            let newIndex;
            do {
                newIndex = Math.floor(Math.random() * aphorisms.length);
            } while (newIndex === currentAphorismIndex && aphorisms.length > 1);
            currentAphorismIndex = newIndex;
            renderAphorism();
        });
    }

    if (aodShare) {
        aodShare.addEventListener('click', async () => {
            const text = aphorisms[currentAphorismIndex];
            const full = `"${text}"\n— Wagner Abrahão, Luz Interior`;
            try {
                await navigator.clipboard.writeText(full);
                showToast('Aforismo copiado', 'fa-copy');
            } catch {
                showToast('Não foi possível copiar', 'fa-exclamation-circle');
            }
        });
    }

    if (aodFavorite) {
        aodFavorite.addEventListener('click', () => {
            const text = aphorisms[currentAphorismIndex];
            toggleFavorite(text, 'Aforismo do dia');
            updateAodFavButton();
        });
    }

    // ===================================================================
    // 5. SISTEMA DE FAVORITOS (persistente em localStorage)
    // ===================================================================
    const FAV_KEY = 'luz-interior-favorites';

    function getFavorites() {
        try {
            return JSON.parse(localStorage.getItem(FAV_KEY)) || [];
        } catch {
            return [];
        }
    }

    function setFavorites(favs) {
        localStorage.setItem(FAV_KEY, JSON.stringify(favs));
    }

    function toggleFavorite(text, source = 'Aforismos do Silêncio Interior') {
        const favs = getFavorites();
        const idx = favs.findIndex(f => f.text === text);
        if (idx >= 0) {
            favs.splice(idx, 1);
            setFavorites(favs);
            showToast('Removido dos favoritos', 'fa-heart-broken');
        } else {
            favs.unshift({ text, source, date: new Date().toISOString() });
            setFavorites(favs);
            showToast('Guardado nos favoritos', 'fa-heart');
        }
        renderFavoritesPanel();
        updateCardFavButtons();
    }

    function renderFavoritesPanel() {
        const list = document.getElementById('fav-list');
        if (!list) return;
        const favs = getFavorites();
        if (favs.length === 0) {
            list.innerHTML = '<p class="fav-empty">Toque no <i class="far fa-heart"></i> de qualquer aforismo para guardá-lo aqui.</p>';
            return;
        }
        list.innerHTML = favs.map((f, i) => `
            <div class="fav-item">
                <p>"${f.text.replace(/"/g, '&quot;')}"<br><span class="author">— ${f.source}</span></p>
                <button class="fav-remove" data-index="${i}" aria-label="Remover dos favoritos"><i class="fas fa-times"></i></button>
            </div>
        `).join('');

        list.querySelectorAll('.fav-remove').forEach(btn => {
            btn.addEventListener('click', function() {
                const idx = parseInt(this.getAttribute('data-index'));
                const favs = getFavorites();
                favs.splice(idx, 1);
                setFavorites(favs);
                renderFavoritesPanel();
                updateCardFavButtons();
                showToast('Removido dos favoritos', 'fa-heart-broken');
            });
        });
    }

    function updateCardFavButtons() {
        const favs = getFavorites();
        document.querySelectorAll('.card').forEach(card => {
            const text = card.getAttribute('data-text');
            const btn = card.querySelector('.fav-btn');
            if (!btn || !text) return;
            const isFav = favs.some(f => f.text === text);
            btn.classList.toggle('favorited', isFav);
            btn.querySelector('i').className = isFav ? 'fas fa-heart' : 'far fa-heart';
        });
        updateAodFavButton();
    }

    // Vincula botões dos cards
    document.querySelectorAll('.card .fav-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const card = this.closest('.card');
            const text = card.getAttribute('data-text');
            const source = card.querySelector('.author')?.textContent.replace('— ', '').trim() || 'Luz Interior';
            if (text) toggleFavorite(text, source);
        });
    });

    // Limpar todos os favoritos
    const clearFavsBtn = document.getElementById('clear-favs');
    if (clearFavsBtn) {
        clearFavsBtn.addEventListener('click', () => {
            if (getFavorites().length === 0) return;
            if (confirm('Limpar todos os favoritos?')) {
                setFavorites([]);
                renderFavoritesPanel();
                updateCardFavButtons();
                showToast('Favoritos limpos', 'fa-trash-alt');
            }
        });
    }

    renderFavoritesPanel();
    updateCardFavButtons();

    // ===================================================================
    // 6. FILTRO DE TEMAS (chips)
    // ===================================================================
    const topicChips = document.querySelectorAll('.topic-chip');
    topicChips.forEach(chip => {
        chip.addEventListener('click', function() {
            const filter = this.getAttribute('data-filter');
            topicChips.forEach(c => c.classList.remove('active'));
            this.classList.add('active');

            document.querySelectorAll('#aforismos-grid .card').forEach(card => {
                const topic = card.getAttribute('data-topic');
                if (filter === 'all' || topic === filter) {
                    card.classList.remove('hidden');
                } else {
                    card.classList.add('hidden');
                }
            });
        });
    });

    // ===================================================================
    // 7. BUSCA INTERNA
    // ===================================================================
    const searchToggle = document.getElementById('search-toggle');
    const searchPanel = document.getElementById('search-panel');
    const closeSearch = document.getElementById('close-search');
    const searchInput = document.getElementById('search-input');
    const searchResults = document.getElementById('search-results');

    function openSearch() {
        searchPanel.classList.add('active');
        searchPanel.setAttribute('aria-hidden', 'false');
        setTimeout(() => searchInput?.focus(), 300);
    }

    function closeSearchPanel() {
        searchPanel.classList.remove('active');
        searchPanel.setAttribute('aria-hidden', 'true');
        if (searchInput) searchInput.value = '';
        if (searchResults) searchResults.innerHTML = '';
    }

    if (searchToggle) searchToggle.addEventListener('click', openSearch);
    if (closeSearch) closeSearch.addEventListener('click', closeSearchPanel);

    // Atalho Ctrl+K / Cmd+K
    document.addEventListener('keydown', function(e) {
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
            e.preventDefault();
            if (searchPanel.classList.contains('active')) {
                closeSearchPanel();
            } else {
                openSearch();
            }
        }
        if (e.key === 'Escape' && searchPanel.classList.contains('active')) {
            closeSearchPanel();
        }
    });

    function getSearchableItems() {
        const items = [];
        document.querySelectorAll('.searchable').forEach(el => {
            let type = 'Conteúdo';
            let text = el.getAttribute('data-text') || '';
            let displayText = text;

            if (el.classList.contains('card')) {
                type = 'Aforismo';
                displayText = el.querySelector('p')?.textContent || text;
            } else if (el.classList.contains('poem')) {
                type = 'Poema';
                const title = el.querySelector('h3')?.textContent || '';
                const body = el.querySelector('.poem-content p')?.textContent || '';
                displayText = title + ' — ' + body.substring(0, 120) + '...';
                text = title + ' ' + body;
            } else if (el.classList.contains('philosophical-text')) {
                type = 'Texto Filosófico';
                const title = el.querySelector('h3')?.textContent || '';
                const body = el.querySelector('.text-content')?.textContent || '';
                displayText = title + ' — ' + body.substring(0, 120) + '...';
                text = title + ' ' + body;
            } else if (el.classList.contains('meditation')) {
                type = 'Meditação';
                const title = el.querySelector('h3')?.textContent || '';
                const body = el.querySelector('.meditation-content')?.textContent || '';
                displayText = title + ' — ' + body.substring(0, 120) + '...';
                text = title + ' ' + body;
            } else if (el.classList.contains('companion')) {
                type = 'Companheiro de Travessia';
                const name = el.querySelector('h3')?.textContent || '';
                const body = el.querySelector('p')?.textContent || '';
                displayText = name + ' — ' + body.substring(0, 120) + '...';
                text = name + ' ' + body;
            }

            items.push({ element: el, type, text: text.toLowerCase(), displayText });
        });
        return items;
    }

    let allSearchable = [];

    function performSearch(query) {
        if (!searchResults) return;
        const q = query.trim().toLowerCase();

        if (q.length === 0) {
            searchResults.innerHTML = '';
            return;
        }

        if (q.length < 2) {
            searchResults.innerHTML = '<p class="search-empty">Digite ao menos 2 letras.</p>';
            return;
        }

        if (allSearchable.length === 0) {
            allSearchable = getSearchableItems();
        }

        const results = allSearchable.filter(item => item.text.includes(q));

        if (results.length === 0) {
            searchResults.innerHTML = `<p class="search-empty">Nenhum resultado para "${query}". Tente outra palavra.</p>`;
            return;
        }

        searchResults.innerHTML = results.slice(0, 20).map((r, i) => {
            // Highlight
            const regex = new RegExp(`(${q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
            const highlighted = r.displayText.replace(regex, '<mark>$1</mark>');
            return `
                <div class="search-result-item" data-idx="${i}">
                    <span class="search-result-type">${r.type}</span>
                    <p class="search-result-text">${highlighted}</p>
                </div>
            `;
        }).join('');

        searchResults.querySelectorAll('.search-result-item').forEach((el, i) => {
            el.addEventListener('click', () => {
                const target = results[i].element;
                closeSearchPanel();
                setTimeout(() => {
                    target.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    target.style.transition = 'background-color 0.8s ease';
                    const original = target.style.backgroundColor;
                    target.style.backgroundColor = 'rgba(122, 154, 149, 0.2)';
                    setTimeout(() => { target.style.backgroundColor = original; }, 1500);
                }, 400);
            });
        });
    }

    if (searchInput) {
        let debounceTimer;
        searchInput.addEventListener('input', function() {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(() => performSearch(this.value), 180);
        });
    }

    // Fechar busca clicando fora da caixa
    if (searchPanel) {
        searchPanel.addEventListener('click', function(e) {
            if (e.target === searchPanel) closeSearchPanel();
        });
    }

    // ===================================================================
    // 8. NARRAÇÃO DE TEXTOS (Web Speech API)
    // ===================================================================
    const audioPlayer = document.getElementById('audio-player');
    const audioTitle = document.getElementById('audio-title');
    const audioPause = document.getElementById('audio-pause');
    const audioStop = document.getElementById('audio-stop');

    let currentUtterance = null;
    let currentButton = null;

    function hasSpeechSupport() {
        return 'speechSynthesis' in window;
    }

    function getBrazilianVoice() {
        const voices = window.speechSynthesis.getVoices();
        // Prefere voz portuguesa do Brasil
        return voices.find(v => v.lang === 'pt-BR') ||
               voices.find(v => v.lang.startsWith('pt')) ||
               voices[0];
    }

    function showAudioPlayer(title) {
        if (!audioPlayer) return;
        if (audioTitle) audioTitle.textContent = title;
        audioPlayer.classList.add('active');
        audioPlayer.setAttribute('aria-hidden', 'false');
    }

    function hideAudioPlayer() {
        if (!audioPlayer) return;
        audioPlayer.classList.remove('active');
        audioPlayer.setAttribute('aria-hidden', 'true');
    }

    function stopSpeech() {
        if (hasSpeechSupport()) {
            window.speechSynthesis.cancel();
        }
        if (currentButton) {
            currentButton.classList.remove('playing');
            currentButton.innerHTML = '<i class="fas fa-volume-up"></i> Ouvir';
            currentButton = null;
        }
        currentUtterance = null;
        hideAudioPlayer();
        if (audioPause) audioPause.innerHTML = '<i class="fas fa-pause"></i>';
    }

    function speakText(text, title, button) {
        if (!hasSpeechSupport()) {
            showToast('Seu navegador não suporta narração', 'fa-exclamation-circle');
            return;
        }

        // Se já está narrando o mesmo, para
        if (currentButton === button && currentUtterance) {
            stopSpeech();
            return;
        }

        stopSpeech();

        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = 'pt-BR';
        utterance.rate = 0.9;
        utterance.pitch = 1;
        utterance.volume = 1;

        const voice = getBrazilianVoice();
        if (voice) utterance.voice = voice;

        utterance.onend = () => {
            stopSpeech();
        };

        utterance.onerror = (e) => {
            console.warn('Erro na narração:', e);
            stopSpeech();
            showToast('Erro na narração', 'fa-exclamation-circle');
        };

        currentUtterance = utterance;
        currentButton = button;

        button.classList.add('playing');
        button.innerHTML = '<i class="fas fa-pause"></i> Narrando';

        showAudioPlayer(title);
        window.speechSynthesis.speak(utterance);
    }

    // Carrega vozes (alguns navegadores só carregam async)
    if (hasSpeechSupport()) {
        window.speechSynthesis.getVoices();
        window.speechSynthesis.onvoiceschanged = () => {
            window.speechSynthesis.getVoices();
        };
    }

    document.querySelectorAll('.read-aloud-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const container = this.closest('.poem, .philosophical-text, .meditation');
            if (!container) return;

            let title = '';
            let text = '';

            if (container.classList.contains('poem')) {
                title = container.querySelector('h3')?.textContent || 'Poema';
                text = container.querySelector('.poem-content')?.textContent || '';
            } else if (container.classList.contains('philosophical-text')) {
                title = container.querySelector('h3')?.textContent || 'Texto';
                text = container.querySelector('.text-content')?.textContent || '';
            } else if (container.classList.contains('meditation')) {
                title = container.querySelector('h3')?.textContent || 'Meditação';
                text = container.querySelector('.meditation-content')?.textContent || '';
            }

            speakText(text, title, this);
        });
    });

    if (audioPause) {
        audioPause.addEventListener('click', () => {
            if (!hasSpeechSupport() || !currentUtterance) return;
            if (window.speechSynthesis.paused) {
                window.speechSynthesis.resume();
                audioPause.innerHTML = '<i class="fas fa-pause"></i>';
            } else {
                window.speechSynthesis.pause();
                audioPause.innerHTML = '<i class="fas fa-play"></i>';
            }
        });
    }

    if (audioStop) {
        audioStop.addEventListener('click', stopSpeech);
    }

    // Se o usuário sair da página, para a narração
    window.addEventListener('beforeunload', stopSpeech);

    // ===================================================================
    // 9. FORMULÁRIO DE NEWSLETTER (preservado)
    // ===================================================================
    const newsletterForm = document.getElementById('newsletter-form');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const emailInput = this.querySelector('input[type="email"]');
            const email = emailInput.value;

            if (email && validateEmail(email)) {
                emailInput.value = '';
                showToast('Obrigado por se inscrever!', 'fa-envelope-open-text');
            } else {
                showToast('Por favor, insira um email válido', 'fa-exclamation-circle');
            }
        });
    }

    function validateEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }

    // ===================================================================
    // 10. ANIMAÇÃO DE SCROLL + NAV ATIVO
    // ===================================================================
    const sections = document.querySelectorAll('section');
    const navItems = document.querySelectorAll('.nav-link');

    const observerOptions = { root: null, rootMargin: '-30% 0px -50% 0px', threshold: 0 };
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const id = entry.target.getAttribute('id');
                navItems.forEach(item => {
                    item.classList.remove('active');
                    if (item.getAttribute('href') === `#${id}`) {
                        item.classList.add('active');
                    }
                });
            }
        });
    }, observerOptions);

    sections.forEach(section => observer.observe(section));

    // Cards entrando com fade suave
    const animElements = document.querySelectorAll('.card, .poem, .meditation, .companion, .philosophical-text');
    const cardObserver = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
                cardObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.08 });

    animElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        cardObserver.observe(el);
    });

    // ===================================================================
    // 11. BOTÃO VOLTAR AO TOPO
    // ===================================================================
    const backToTopButton = document.createElement('button');
    backToTopButton.innerHTML = '<i class="fas fa-chevron-up"></i>';
    backToTopButton.className = 'back-to-top';
    backToTopButton.setAttribute('aria-label', 'Voltar ao topo');
    document.body.appendChild(backToTopButton);

    window.addEventListener('scroll', function() {
        if (window.pageYOffset > 300) {
            backToTopButton.classList.add('show');
        } else {
            backToTopButton.classList.remove('show');
        }
    });

    backToTopButton.addEventListener('click', function() {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

});
